# KC-Player — native app scaffold

This is not a runnable Android project by itself — it's everything that
can be prepared without running the Capacitor CLI (which needs Node.js
and internet access to download the Android project template). You'll
run a few commands once on your own computer to turn this into a real
Android Studio project.

## What's in here

- `www/index.html` — the app itself (this is the same app you've been
  testing in the browser, with the plain-browser-only bits removed)
- `package.json`, `capacitor.config.json` — Capacitor project config
- `native-plugin-files/` — the custom native permission + video-listing
  code, ready to drop into the Android project once it's generated

## One-time setup (on a computer with Node.js installed)

1. Install Node.js if you don't have it: https://nodejs.org (LTS version)
2. Open a terminal in this folder and run:
   ```
   npm install
   npx cap add android
   ```
   This downloads and generates the actual `android/` folder — the full
   Android Studio project — which isn't included here since it requires
   a live download from Google's Maven repository.

3. Copy the plugin file into place:
   ```
   cp native-plugin-files/MediaAccessPlugin.kt android/app/src/main/java/com/kcplayer/app/
   ```

4. Open `android/app/src/main/AndroidManifest.xml` and add the two
   permission lines from `native-plugin-files/AndroidManifest-additions.xml`
   (inside `<manifest>`, above `<application>`).

5. Open `android/app/src/main/java/com/kcplayer/app/MainActivity.kt`
   and register the plugin, following
   `native-plugin-files/MainActivity-additions.kt` — add the
   `registerPlugin(MediaAccessPlugin::class.java)` line before
   `super.onCreate(...)`.

6. Sync and open in Android Studio:
   ```
   npx cap sync
   npx cap open android
   ```

7. In Android Studio, connect your phone (with USB debugging on) or
   start an emulator, and hit Run. That installs a real native
   KC-Player — not a browser tab, not a home-screen shortcut — with
   the one-time permission behavior described earlier.

## What still needs building from here

This scaffold gets the permission + video-listing plumbing in place.
Still to wire up as native code (currently only working in the browser
prototype): the capture/record pipeline, the editor's crop/zoom/text/
effects, and export. Those were built out in detail earlier — happy to
turn any of them into native Kotlin next, the same way this permission
piece was done.
