// android/app/src/main/java/com/kcplayer/app/MainActivity.kt
// (Capacitor generates this file when you run `npx cap add android` —
// edit the existing file, don't create a new one.)

package com.kcplayer.app

import android.os.Bundle
import com.getcapacitor.BridgeActivity

class MainActivity : BridgeActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        registerPlugin(MediaAccessPlugin::class.java)  // <-- add this line before super.onCreate()
        super.onCreate(savedInstanceState)
    }
}
